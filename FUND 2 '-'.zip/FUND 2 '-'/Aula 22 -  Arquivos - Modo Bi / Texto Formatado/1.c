/**
 * @file 1.c
 * @author Leonardo Novi
 * @brief Faça um programa que gere 100 números aleatórios. Esse programa deverá, em seguida,armazenar esses números em um arquivo binário.
 * @version 0.1
 * @date 2023-05-26
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <stdio.h>
#include <stdlib.h>


void GeradoraDeNumeros(){

FILE *Arquivo = fopen("arquivo.dat", "wb");
if (Arquivo == NULL)
{
    perror("Erro ao Abrir!!");
}


int vetor[100];

for (int i = 0; i < 100; i++)
{

    vetor[i] = rand();
    fwrite(vetor,sizeof(int),100,Arquivo);
}

fclose(Arquivo);

}


int main(){
FILE *Arq = fopen("arquivo.dat", "rb");
if (Arq == NULL)
{
    perror("Erro ao abrir!!");
}
int vetor[100];
GeradoraDeNumeros();

fread(vetor, sizeof(int),100,Arq);
for (int i = 0; i < 100; i++)
{
    printf("%d\n", vetor[i]);
}

fclose(Arq);
return 0;
}