/**
 * @file 2.c
 * @author Elabore um programa que leia um arquivo binário contendo 100 números. Mostre na tela a soma desses números
 * @brief
 * @version 0.1
 * @date 2023-05-26
 *
 * @copyright Copyright (c) 2023
 *
 */ \
#include<stdio.h>
#include <stdlib.h>

void GeradoraDeNumeros()
{

    FILE *Arquivo = fopen("arquivo.dat", "wb");
    if (Arquivo == NULL)
    {
        perror("Erro ao Abrir!!");
    }

    int vetor[100];

    for (int i = 0; i < 100; i++)
    {

        vetor[i] = rand() % 100;
        fwrite(vetor, sizeof(int), 100, Arquivo);
    }

    fclose(Arquivo);
}

int main()
{
    GeradoraDeNumeros();
    FILE *Arq = fopen("arquivo.dat", "rb");
    if (Arq == NULL)
    {
        perror("Erro ao abrir!!");
    }
    int vetor[100];
    int soma = 0;


    fread(vetor, sizeof(int), 100, Arq);

    for (int i = 0; i < 100; i++)
    {
        soma = vetor[i] + soma;
        printf("%d\n", vetor[i]);
    }
    fclose(Arq);
    printf("-------------------------------------\n");
    printf("SOMA: %d\n", soma);
    return 0;
}