/**
 * @file 2.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Elabore uma função que receba por parâmetro o sexo (char) e a altura de uma pessoa (real), calcule e retorne seu peso ideal. 
 * Para isso, utilize as fórmulas a seguir:
Para homens: (72.7*altura) - 58
Para mulheres: (62.1*altura) – 44.7
 * @version 0.1
 * @date 2023-03-17
 *
 * @copyright Copyright (c) 2023
 *
 */



#include <stdlib.h>
#include <stdio.h>



float peso_ideal(char sexo, float altura)
{
    float peso_ideal = 0;

    if (sexo == 'M')
    {
        peso_ideal = (72.7 * altura) - 58;
    }
    else if (sexo == 'F')
    {
        peso_ideal = (62.1 * altura) - 44.7;
    }
    return peso_ideal;
}

int main()
{
    char sexo;
    float altura;

    printf("Forneça o sexo (M ou F): ");
    scanf("%c", &sexo);

    printf("Forneça a altura: ");
    scanf("%f", &altura);

    printf("Peso ideal: %.2f\n", peso_ideal(sexo, altura));

    return 0;
}