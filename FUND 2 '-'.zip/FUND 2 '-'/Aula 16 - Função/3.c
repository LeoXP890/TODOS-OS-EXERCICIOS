/**
 * @file 3.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Escreva um procedimento que recebe por parâmetro as 3 notas de um aluno e uma letra. Se a letra for A, o procedimento calcula a 
 * média aritmética das notas do aluno, se for P, 
 * a sua média ponderada (pesos: 5, 3 e 2) e se for S, a soma das notas. O valor calculado também deve ser retornado e exibido na função main.
 * @version 0.1
 * @date 2023-03-17
 *
 * @copyright Copyright (c) 2023
 *
 */



#include <stdio.h>
#include <stdlib.h>


float media(int n1, int n2, int n3, char calculoMedia){

float media_P;
float media_A;

if (calculoMedia == 'A')
{
   media_A =  (n1 + n2 + n3)/3;
    return media_A;

}else if (calculoMedia == 'P')
{
    media_P = ((n1*5) + (n2*3) + (n3*2)) / 10;
    return media_P;
    
}

}


int main(){

    char calculo;
    int N[3];
    float Media; 

        printf("Forneça as 3 notas do aluno...\n");
    for (int i = 0; i < 3; i++)
    {
    printf("Nota %d: ", i++);
    scanf("%d", &N[i]);
}

printf("Para calcular a media ponderada digite (P)...\n ");
printf("Para calcular a media aritimetica digite (A)...");
scanf("%c", &calculo);

Media = media(N[0], N[1], N[2], calculo);
    printf("Media: %.2f \n", media);

return 0;
}