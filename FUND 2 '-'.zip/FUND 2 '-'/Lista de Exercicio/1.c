/**
 * @file 1.c
 * @brief Crie uma estrutura representando um atleta. Essa estrutura deve conter o nome do atleta, seu esporte, idade e altura.
 * Agora, escreva um programa que leia os dados de cinco atletas. Calcule e exiba os nomes do atleta mais alto e do mais velho.
 * @version 0.1
 * @date 2023-04-14
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void LerString(char *string, int tamanho)
{
    setbuf(stdin, NULL);
    fgets(string, tamanho, stdin);
    string[strcspn(string, "\n")] = '\0';
}

typedef struct
{
    char nome[21];
    char esporte[21];
    int idade;
    float altura;
} ATLETAS;

int main()
{
    ATLETAS dados[5];
    int maisVelho = 0;
    int maisAlto = 0;

    for (int i = 0; i < 5; i++)
    {
        setbuf(stdin, NULL);
        printf("Nome: ");
        LerString(dados[i].nome, 21);

        printf("Esporte : ");
        LerString(dados[i].esporte, 21);

        printf("Idade: ");
        if (scanf("%d", &dados[i].idade) != 1)
        {
            printf("Idade invalida, tente novamente.\n");
            i--;
            continue;
        }

        setbuf(stdin, NULL);
        printf("Altura: ");
        if (scanf("%f", &dados[i].altura) != 1)
        {
            printf("Altura invalida, tente novamente.\n");
            i--;
            continue;
        }
    }

    for (int i = 1; i < 5; i++)
    {
        if (dados[i].idade > dados[maisVelho].idade)
        {
            maisVelho = i;
        }
        if (dados[i].altura > dados[maisAlto].altura)
        {
            maisAlto = i;
        }
    }

    // Imprimir os resultados
    printf("O atleta mais velho e': %s\n", dados[maisVelho].nome);
    printf("O atleta mais alto e': %s, com %.2f metros\n", dados[maisAlto].nome, dados[maisAlto].altura);

    return 0;
}