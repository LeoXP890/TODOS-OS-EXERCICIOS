/**
 * @file 2.c
 * @author Leonardo Novi
 * @brief Usando a estrutura “atleta” do exercício anterior, escreva um programa que leia os dados de cinco atletas e os exiba por ordem de idade, 
 * do mais velho para o mais novo.
Dica: Procure pelo algoritmo BubbleSort no Google
 * @version 0.1
 * @date 2023-04-14
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void bubbleSort(int arr[], int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void LerString(char *string, int tamanho)
{
    setbuf(stdin, NULL);
    fgets(string, tamanho, stdin);
    string[strcspn(string, "\n")] = '\0';
}

typedef struct
{
    char nome[21];
    char esporte[21];
    int idade;
    float altura;
} ATLETAS;

int main()
{
    ATLETAS dados[5];
    int maisVelho = 0;
    int maisAlto = 0;

    for (int i = 0; i < 5; i++)
    {
        setbuf(stdin, NULL);
        printf("Nome: ");
        LerString(dados[i].nome, 21);

        printf("Esporte : ");
        LerString(dados[i].esporte, 21);

        printf("Idade: ");
        if (scanf("%d", &dados[i].idade) != 1)
        {
            printf("Idade invalida, tente novamente.\n");
            i--;
            continue;
        }

        setbuf(stdin, NULL);
        printf("Altura: ");
        if (scanf("%f", &dados[i].altura) != 1)
        {
            printf("Altura invalida, tente novamente.\n");
            i--;
            continue;
        }
    }


    int arr[5];
    for (int i = 0; i < 5; i++)
    {
        arr[i] = dados[i].idade;
    }

    bubbleSort(arr, 5);

    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            if (arr[i] == dados[j].idade)
            {
                printf("Nome: %s \n", dados[j].nome);
                printf("Esporte: %s \n", dados[j].esporte);
                printf("Idade: %d \n", dados[j].idade);
                printf("Altura: %.2f \n", dados[j].altura);
                printf("");
            }
        }
    }

    return 0;
}
