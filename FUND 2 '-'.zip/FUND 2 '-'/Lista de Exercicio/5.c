/**
 * @file 5.c
 * @author Leonardo Novi
 * @brief Crie um programa que gerencie um cadastro de materiais para obras disponíveis em um fornecedor. Cada material contém: nome (tamanho máximo 40 caracteres), quantidade (int) e preço (float) de no máximo 15 produtos. O programa deve possuir um menu para que o usuário do programa consiga manipular os cadastros. Nesse menu

a) Ao digitar (I), deve-se realizar inserção de um material na primeira posição que estiver livre;
b) Ao digitar (R), deve-se remover o material pelo índice (a ser fornecido pelo usuário );
c) Ao digitar (L), deve-se listar todos os cadastros não vazios;
d) Ao digitar (P), deve-se solicitar o nome de um material e exibir a quantidade e o preço;
e) Ao digitar (V), deve-se listar todos os produtos que tenham a quantidade igual a 0;
f) Ao digitar (S), deve sair do programa.

Obs: Cada opção do menu deve ser implementada em uma função diferente. Após cada função o menu deve ser reexibido (Exceto opção S)
Não utilize variáveis globais. Utilize passagem de parâmetros quando necessário.
Não se esqueça de criar um método para gerenciar qual posição do vetor está vazia ou não.
 * @version 0.1
 * @date 2023-04-26
 *
 * @copyright Copyright (c) 2023
 *
 */

