/**
 * @file 4.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Faça uma função que receba um inteiro N como parâmetro. Calcule e retorne o resultado da seguinte série S:
 * 
 * A = 4piR²
 * V = 4/3(piR³)
 * @version 0.1
 * @date 2023-04-26
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14

void conta(float n, float *v)
{
    float A, R, Volume;
    R = n;

    A = 4 * PI * pow(R, 2);
    Volume = (4.0 / 3.0) * PI * pow(R, 3);

    *v = Volume;

    printf("A = %.2f, V = %.2f\n", A, Volume);
}

int main()
{
    float N, v;

    printf("Forneça o valor de N: ");
    scanf("%f", &N);

    conta(N, &v);

    return 0;
}