/**
 * @file 3.c
 * @author Leonardo Novi
 * @brief Elabore uma função que receba como parâmetro um valor inteiro n e gere como saída um triângulo lateral formado por asteriscos conforme o 
 * exemplo a seguir, em que usamos n = 4:
 *
 **
 ***
 ****
 ***
 **
 *
 * @version 0.1
 * @date 2023-04-26
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <stdio.h>
#include <stdlib.h>


int inteiro_N(int n){


    for(int i = 0; i < n; i++){//laço para imprimir a quantidade de linhas
        for(int j = 0; j <= i; j++){//laço para imprimir a quantidade de colunas
            printf("*");
        }
        printf("\n");
    }

    for(int i = n; i > 0; i--){//laço para imprimir a quantidade de linhas
        for(int j = 0; j < i; j++){//laço para imprimir a quantidade de colunas
            printf("*");
        }
        printf("\n");
    }

    return 0;

}

int main(){
int N;

printf("Forneça uma valor: ");
scanf("%d", &N);//recebe N

inteiro_N(N);//chama a função





    return 0;
}