/**
 * @file 5.c
 * @author Leonardo Novi
 * @brief Um problema típico em ciência da computação consiste em converter um número da sua forma decimal para binária. 
 * Crie um algoritmo recursivo para resolver esse problema.

●Solução trivial: x=0 quando o número inteiro já foi convertido para binário

●Passo da recursão: saber como x/2 é convertido. Depois, imprimir um dígito (0 ou 1) dado o sucesso da divisão.

Texto de resposta

 * @version 0.1
 * @date 2023-04-14
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <stdio.h>

void binario(int n){
    if(n==0){
        return;
    }else{
        binario(n/2);
        printf("%d", n%2);
    }
}

int main(){
    int n;
    printf("Digite um numero: ");
    scanf("%d", &n);
    binario(n);
    return 0;
}