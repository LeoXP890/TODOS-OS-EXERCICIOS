/**
 * @file 1.c
 * @author  leonardo novi (you@domain.com)
 * @brief Crie uma função que retorne x*y através de operação de soma. A função recebe x e y por parâmetro
 * @version 0.1
 * @date 2023-04-05
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>


int multiplicacao(int x, int y)
{
    if (y == 0)
    {
        return 0;
    }
    else
    {
        return x + multiplicacao(x, y - 1);
    }
}


int main()
{
    int x, y;
    printf("Digite o valor de x: ");
    scanf("%d", &x);
    printf("Digite o valor de y: ");
    scanf("%d", &y);
    printf("O resultado de %d * %d é: %d", x, y, multiplicacao(x, y));
    return 0;
}
