/**
 * @file 2.c
 * @author Leonardo Novi
 * @brief Crie uma função que retorne x elevado a y através de operação de multiplicação. A função recebe x e y por parâmetro
 * @version 0.1
 * @date 2023-04-05
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int potencia(int x, int y)
{
    if (y == 0)
    {
        return 1;
    }
    else
    {
        return x * potencia(x, y - 1);
    }
}

int main()
{
    int x, y;
    printf("Digite o valor de x: ");
    scanf("%d", &x);
    printf("Digite o valor de y: ");
    scanf("%d", &y);
    printf("O resultado de %d ^ %d é: %d", x, y, potencia(x, y));
    return 0;
}