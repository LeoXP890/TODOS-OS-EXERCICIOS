/**
 * @file 6.c
 * @author your name (you@domain.com)
 * @brief Considere a função X abaixo:

int X(int a){
  if(a <=0) return0;
  else return a + X(a-1);
}//X

O que essa função faz? Escreva uma função não-recursiva que resolve o mesmo problema.
 * @version 0.1
 * @date 2023-04-14
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <stdio.h>

int X(int a){
    if(a <=0) return 0;
    else return a + X(a-1);
}//X

int main(){
    int a;
    printf("Digite um numero: ");
    scanf("%d", &a);
    printf("X(%d) = %d", a, X(a));
    return 0;
}