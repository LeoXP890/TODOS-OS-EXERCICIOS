/**
 * @file 4.c
 * @author Leonardo Novi
 * @brief Faça uma função recursiva que retorne o n-ésimo termo da sequência de Fibonacci, sendo que n é recebido por parâmetro. Utilize essa função para desenvolver um programa que mostre no main() os n termos dessa sequência na tela, a partir do valor de n recebido pelo teclado. Sabe-se que o 1º termo é 0 e o 2º termo é 1.

Texto de resposta

 * @version 0.1
 * @date 2023-04-05
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n)
{
    if (n == 0)
    {
        return 0;
    }
    else if (n == 1)
    {
        return 1;
    }
    else
    {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

int main()
{
    int n;
    printf("Digite o valor de n: ");
    scanf("%d", &n);
    printf("O %dº termo da sequência de Fibonacci é: %d", n, fibonacci(n));
    return 0;
}
