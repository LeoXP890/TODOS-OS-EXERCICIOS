/**
 * @file 2.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Crie um programa de cadastro que receba, armazene, e em seguida, exiba os dados de 5 pessoas.
Cada pessoa possui: nome, idade, peso, data de nascimento, brasileiro ou estrangeiro. 
Caso seja Brasileiro, armazene o CPF, caso estrangeiro, armazene o passaporte.
Regra: Utilize structs, typedef, union e enum.
 * @version 0.1
 * @date 2022-08-26
 *
 * @copyright Copyright (c) 2022
 *
 */




#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define MAX 5

typedef struct 
{
    int dia;
    int mes;
    int ano;
}Data;

enum Nacionalidade{ Brasil, Estrangeiro};

typedef union 
{
    char passaporte[50];
    char cpf[50];

}Documento;

typedef struct 
{
    char nome[21];
    int idade;
    float peso;
    enum Nacionalidade nacionalidade;
    Documento documento;
    Data data;
}Pessoa;





int main(){
    Pessoa dados[MAX];
    int resposta[MAX];
    char compara_nacionalidade[21] = "Brasil";
    for (int i = 0; i < MAX; i++)
    {
        //RECEBE O NOME DA PESSOA
        printf("Qual o nome da pessoa?: ");
        setbuf(stdin, NULL);//LIMPA O LIXO
        fgets(dados[i].nome, 21, stdin);
        dados[i].nome[strcspn(dados[i].nome, "\n")] = '\0';

        //RECEBE A IDADE
        printf("Digita a idade da pessoa: \n");
        scanf("%i", &dados[i].idade);

        //RECEBE PESO
        printf("Forneça o peso da pessoa: \n");
        scanf("%f", &dados[i].peso);

        //RECEBE A DATA DE NASCIMENTO
        printf("Digite o aniversario: \n");
        scanf("%i%i%i", &dados[i].data.dia, &dados[i].data.ano, &dados[i].data.ano);
        

        //RECEBE A NACIONALIDADE, CASO SEJA BRASILEIRO PEDE O CPF, CASO SEJA ESTRANGEIRO PEDE O RG
        printf("É Brasileiro?\n");
        printf("1- Sim\n");
        printf("2- Não\n");
        scanf("%i", &resposta[i]);
        //PEDE PASSAPORTE OU CPF
        if (resposta[i] == 1)
        {
            // CASO SEJA 1, O PROGRAMA PEDE O CPF+
            printf("\nForneça o CPF: ");
            setbuf(stdin, NULL);
            fgets(dados[i].documento.cpf, 50, stdin);
            dados[i].documento.cpf[strcspn(dados[i].documento.cpf, "\n")] = '\0';
           
        }else
        {
            // CASO SEJA 2, O PROGRAMA PEDE O PASSAPORTE
            printf("\nForneça o Passaporte: ");
            setbuf(stdin, NULL);
            fgets(dados[i].documento.passaporte, 50, stdin);
            dados[i].documento.passaporte[strcspn(dados[i].documento.passaporte, "\n")] = '\0';
        }
        
        
       
      
       fflush(stdin);
       
    }
    
    for (int i = 0; i < MAX; i++)
    {
        printf("Pessoas Cadastradas: \n");
        printf("Nome: %s\n", dados[i].nome);
        printf("Aniversario: %i/%i/%i\n", dados[i].data.dia, dados[i].data.mes, dados[i].data.ano);
        printf("Idade: %i\n", dados[i].idade);
        printf("Peso: %.2f\n", dados[i].peso);
        if (resposta[i] == 1)
        {
            printf("CPF: %s\n", dados[i].documento.cpf);
        }else if (resposta[i] == 2)
        {
            printf("Passaporte: %s\n", dados[i].documento.passaporte);
        }
        
        
    }
    
    




    return 0;
}