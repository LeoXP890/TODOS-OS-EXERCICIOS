/**
 * @file 1.c
 * @author Leonardo Novi  (you@domain.com)
 * @brief Crie uma enumeração representando os meses do ano. Agora, escreva um programa que leia um valor inteiro do teclado e exiba
 * o nome do mês correspondente e a quantidade de dias que ele possui.
 * Texto de resposta
 * @version 0.1
 * @date 2022-08-26
 *
 * @copyright Copyright (c) 2022
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){

    enum meses {//enum com os meses iniciando no mes 1 janeiro até o mes 12 dezembro
        Janeiro = 1,
        Fevereiro,
        Marco,
        Abril,
        Maio,
        Junho,
        Julho,
        Agosto,
        Setembro,
        Outubro,
        Novembro,
        Dezembro
    };
    int mes;//criando a variavel mes
    printf("Digite o numero do mes: ");//pede para o usuario um numero para identificar o mes
    scanf("%d", &mes);//recebe do teclado o numero correspondente
    switch(mes){//switch para printar o mes de acordo com o numero
        case Janeiro:
            printf("O mes é Janeiro\n");//caso o numero seja 1
            break;
        case Fevereiro:
            printf("O mes é Fevereiro\n");//caso o numero seja 2
            break;
        case Marco:
            printf("O mes é Marco\n");//caso o numero seja 3
            break;
        case Abril:
            printf("O mes é Abril\n");//...
            break;
        case Maio:
            printf("O mes é Maio\n");//...
            break;
        case Junho:
            printf("O mes é Junho\n");//...
            break;
        case Julho:
            printf("O mes é Julho\n");//...
            break;
        case Agosto:
            printf("O mes é Agosto\n");//...
            break;
        case Setembro:
            printf("O mes é Setembro\n");//...
            break;
        case Outubro:
            printf("O mes é Outubro\n");//...
            break;
        case Novembro:
            printf("O mes é Novembro\n");//...
            break;
        case Dezembro:
            printf("O mes é Dezembro\n");//...
            break;
        default:
            printf("Mes invalido\n");//...
            break;
    }







    return 0;
}