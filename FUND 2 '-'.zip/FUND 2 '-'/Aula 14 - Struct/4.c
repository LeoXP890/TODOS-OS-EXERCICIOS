/**
 * @file 4.c
 * @author your name (you@domain.com)
 * @brief Faça um programa que controla o consumo de energia dos eletrodomésticos de uma casa e:

–Crie e leia 5 eletrodomésticos que contém nome (máximo 15 letras), potência (real, em kW) e tempo ativo por dia (real, em horas).

–Leia um tempo t (em dias),
calcule e mostre o consumo total na casa e o consumo relativo de cada eletrodoméstico (consumo/consumo total) nesse período de tempo.
Apresente este último dado em porcentagem.
 * @version 0.1
 * @date 2023-03-08
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char eletrodomesticos[5][20]; // declaração de variável do tipo char
    int dias[5];
    float potencia[5];      // declaração de variável do tipo float
    float tempo[5];         // declaração de variável do tipo float
    float consumo[5];       // declaração de variável do tipo float
    float salva_consumo[5]; // declaração de variável do tipo float

    for (int i = 0; i < 5; i++)
    {
        printf("Digite o nome do eletrodomestico: ");                           // mensagem para o usuário
        setbuf(stdin, NULL);                                                    // limpa o buffer do teclado
        fgets(eletrodomesticos[i], 20, stdin);                                  // nome do eletrodomestico
        eletrodomesticos[i][strcspn(eletrodomesticos[i], "\n")] = 0;            // remove o \n do nome do eletrodomestico
        printf("Digite a potencia do eletrodomestico em Watts: ");              // mensagem para o usuário
        scanf("%f", &potencia[i]);                                              // potencia do eletrodomestico
        printf("Digite o tempo ativo do eletrodomestico por dia (em horas): "); // mensagem para o usuário
        scanf("%f", &tempo[i]);                                                 // tempo ativo do eletrodomestico
        printf("Quantos dias do mes o eletrodomestico foi utilizado: ");        // mensagem para o usuário
        scanf("%d", &dias[i]);                                                  // quantidade de dias do eletrodomestico
        // potência (W) x horas de uso por dia (h) x dias de uso no mês / 1000.
        consumo[i] = (potencia[i] * tempo[i] * dias[i]) / 1000; // calculo do consumo do eletrodomestico

        salva_consumo[i] = consumo[i]; // salva o consumo do eletrodomestico
    }

    printf("Consumo do equipamento %s é de %.2fKwh\n", eletrodomesticos[0], consumo[0]);                       // mensagem para o usuário
    printf("Consumo do equipamento %s é de %.2fkwh\n", eletrodomesticos[1], consumo[1]);                       // mensagem para o usuário
    printf("Consumo do equipamento %s é de %.2fKwh\n", eletrodomesticos[2], consumo[2]);                       // mensagem para o usuário
    printf("Consumo do equipamento %s é de %.2fKwh\n", eletrodomesticos[3], consumo[3]);                       // mensagem para o usuário
    printf("Consumo do equipamento %s é de %.2fKwh\n", eletrodomesticos[4], consumo[4]);                       // mensagem para o usuário
    printf("Cosumo total da casa: %.2fKwh\n", consumo[0] + consumo[1] + consumo[2] + consumo[3] + consumo[4]); // mensagem para o usuário

    return 0;
}