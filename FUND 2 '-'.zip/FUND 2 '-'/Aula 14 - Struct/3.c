/**
 * @file 3.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Construa uma estrutura aluno com nome, curso e 4 notas,
média e situação. Leia as informações nome, curso e notas do
teclado, calcule a média e armazene a situação do aluno.
 media ≥ 7 → Aprovado;
 3 ≤ media < 7 → Exame;
 media < 3 → Reprovado;
 * @version 0.1
 * @date 2023-03-08
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct 
{
    char nome[21];
    char curso[21];
    float notas[4];
    float media;
    char situacao[21];
}Aluno;

int main(){
Aluno aluno;

printf("Digite o nome do aluno: ");
fgets(aluno.nome, 21, stdin);
aluno.nome[strcspn(aluno.nome, "\n")] = 0;
setbuf(stdin, NULL);

printf("Digite o Curso do aluno: ");
fgets(aluno.curso, 21,stdin);
aluno.curso[strcspn(aluno.curso, "\n")] = 0;

printf("Digite as notas do aluno nos 4 semestres\n");
for (int i = 0; i < 4; i++)
{
printf("Nota %d: ", i + 1);
scanf("%f", &aluno.notas);
}


    aluno.media = (aluno.notas[0] + aluno.notas[1] + aluno.notas[2] + aluno.notas[3])/4;

    if (aluno.media >= 7)
    {                                             // se a média for maior ou igual a 7
printf("Aprovado com media %.2f\n", aluno.media); // mensagem para o usuário
    }
    else if (aluno.media >= 3 && aluno.media < 7)
    {                                                  // se a média for maior ou igual a 3 e menor que 7
printf("Esta de exame com media %.2f\n", aluno.media); // mensagem para o usuário
    }
    else
    {                                                   // se a média for menor que 3
printf("Esta reprovado com media %.2f\n", aluno.media); // mensagem para o usuário
    }

    return 0;
}