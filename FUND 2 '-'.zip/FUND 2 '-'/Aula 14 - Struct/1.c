/**
 * @file 1.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Crie uma estrutura para representar as coordenadas de
um ponto no plano (posições X e Y). Em seguida, declare
e leia do teclado dois pontos e exiba a distância entre
eles.
 * @version 0.1
 * @date 
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>


typedef struct 
{
    float ponto_x;
    float ponto_y;
}Posicoes;

int main(){
    Posicoes posicoes;
    float distancia;
printf("Digite o ponto X: ");
scanf("%f", &posicoes.ponto_x);
printf("Digite o ponto Y: ");
scanf("%f", &posicoes.ponto_y);

printf("Ponto X: %.2f \n", posicoes.ponto_x);
printf("Ponto Y: %.2f \n", posicoes.ponto_y);

if (posicoes.ponto_x > posicoes.ponto_y)
{
    distancia = posicoes.ponto_x - posicoes.ponto_y;
    printf("Distancia entre os pontos: %.2f", distancia);
}else{
    distancia = posicoes.ponto_y - posicoes.ponto_x;
    printf("Distancia entre os pontos: %.2f", distancia);
}


return 0;
}