/**
 * @file 2.c
 * @author Leonardo Novi (you@domain.com)
 * @brief Escreva um trecho de código para fazer a criação dos
novos tipos de dados conforme solicitado abaixo:
 Horário: composto de hora, minutos e segundos.
 Data: composto de dia, mês e ano.
 Compromisso: local, horário e texto que descreve o
compromisso.
 * @version 0.1
 * @date 2023-03-08
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct 
{
    int Hora;
    int Minutos;
    int Segundos;
}Horario;


typedef struct 
{
    int Dia;
    int Mes;
    int Ano;
}Data;

typedef struct 
{
  char local[41];
  char mensagem[50];
  Horario hora;
  Data Da;  
}Compromisso;

int main(){


Compromisso compromisso = {"Rua paes leme 459", "Venha comemorar meu aniversario com um churrasco"};
compromisso.hora.Hora = 19;
compromisso.hora.Minutos = 30;
compromisso.hora.Segundos = 00;
compromisso.Da.Dia = 10;
compromisso.Da.Mes = 10;
compromisso.Da.Ano = 2023;

printf("%s, %s\n",compromisso.local, compromisso.mensagem);
printf("Horario: %d:%d:%.2d\n", compromisso.hora.Hora, compromisso.hora.Minutos, compromisso.hora.Segundos);
printf("Data: %d/%d/%d\n", compromisso.Da.Dia, compromisso.Da.Mes, compromisso.Da.Ano);







    return 0;
}






