/**
 * @file 2.c
 * @author Leonardo Novi
 * @brief Reescreva o exercício anterior utilizando a estrutura horário (contendo hora, minuto e segundo) e passando a estrutura por referência. Utilize o seguinte protótipo da função:
void converteHorario(int total_segundos, Horario* hor)
 * @version 0.1
 * @date 2023-03-29
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct 
{
    int hora;
    int minuto;
    int segundo;
}Horario;


void converteHora(int total_segundos, Horario* horario)
{

    horario->hora = total_segundos / 3600;
    horario->minuto = (total_segundos % 3600) / 60;
    horario->segundo = (total_segundos % 3600) % 60;
}

int main()
{

    int total_segundo;
    Horario* horas;

    printf("Total de segundos: ");
    scanf("%d", &total_segundo);
    converteHora(total_segundo, &horas);
    printf("%d:%d:%d /n", horas->hora, horas->minuto, horas->segundo);


    return 0;
}
