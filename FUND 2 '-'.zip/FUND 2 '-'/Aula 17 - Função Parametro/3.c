/**
 * @file 3.c
 * @author Leonardo Novi
 * @brief Crie um Sistema de Gerenciamento de Bandas seguindo os seguintes passos:
a) Defina uma estrutura que irá representar bandas de música. Essa estrutura deve ter o nome da banda, que tipo de música ela toca, o número de integrantes 
e em que posição do ranking essa banda está dentre as suas 5 bandas favoritas;
b) Crie uma função para preencher as 5 estruturas de bandas criadas no exemplo passado. Após criar e preencher, exiba todas as informações das bandas/estruturas.
c) Crie uma função que peça ao usuário um número de 1 até 5. Em seguida, seu programa deve exibir informações da banda cuja posição no seu ranking é a que foi solicitada pelo usuário;
d) Crie uma função que peça ao usuário um tipo de música e exiba as bandas com esse tipo de música no seu ranking.
e) Crie uma função que peça o nome de uma banda ao usuário e diga se ela está entre suas bandas favoritas ou não;
f) Agora junte tudo e crie um menu com as opções de preencher as estruturas e todas as opções das questões passadas.
 * @version 0.1
 * @date 2023-03-29
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 5
void Preenche_Dados(Bandas bandas[MAX]);
void buscaBanda(Bandas bandas[MAX]);
void LerString(char *string, int tamanho);

typedef struct
{
    char nome[21];
    char tipo_de_musica[21];
    int ranking;

}Bandas;

void LerString(char *string, int tamanho)
{
    setbuf(stdin, NULL);
    fgets(string, tamanho, stdin);
    string[strcspn(string, "\n")] = '\0';
}

void Preenche_Dados(Bandas bandas[MAX])
{

    printf("--=Gerenciamento de Bandas=--\n");
    for (int i = 0; i < MAX; i++)
    {

        setbuf(stdin, NULL);
        printf("Nome: ");
        fgets(bandas[i].nome, 21, stdin);
        bandas[i].nome[strcspn(bandas[i].nome, "\n")] = '\0';

        setbuf(stdin, NULL);
        printf("Tipo de Musica: ");
        fgets(bandas[i].tipo_de_musica, 21, stdin);
        bandas[i].tipo_de_musica[strcspn(bandas[i].tipo_de_musica, "\n")] = '\0';

        printf("Ranking: ");
        scanf("%d", &bandas[i].ranking);
    }
}

void buscaBanda(Bandas bandas[MAX])
{

int Nbusca;


printf("-=Pesquisa de Bandas=-\n");
printf("Lista de Bandas: \n");
for (int i = 0; i < MAX; i++)
{
    printf("Banda %d: \n", i + 1);
    printf("Nome: %s\n", bandas[i].nome);
    printf("\n");
}

printf("Para buscar as informações da banda digite o numero respectivo da banda\n");
scanf("%d", &Nbusca);

if (Nbusca == 1 && Nbusca == 2 && Nbusca == 3 && Nbusca == 4 && Nbusca == 5)
{
    printf("Banda %d: \n", Nbusca);
    printf("Nome: %s\n", bandas[Nbusca - 1].nome);
    printf("Tipo de Musica: %s\n", bandas[Nbusca - 1].tipo_de_musica);
    printf("Ranking: %d\n", bandas[Nbusca - 1].ranking);
}
else
{
    printf("Opção invalida");
}


}

void buscaTipoMusica(Bandas bandas[MAX])
{

char TipoMusica[21];

printf("-=Busca de Bandas pelo tipo de musica=-\n");
printf("Insira o tipo de musica: ");
fgets(TipoMusica, 21, stdin);
TipoMusica[strcspn(TipoMusica, "\n")] = '\0';
setbuf(stdin, NULL);

for (int i = 0; i < MAX; i++)
{
    if (strcmp(TipoMusica, bandas[i].tipo_de_musica) == 0)
    {
        printf("Banda %d: \n", i + 1);
        printf("Nome: %s\n", bandas[i].nome);
        printf("Tipo de Musica: %s\n", bandas[i].tipo_de_musica);
        printf("Ranking: %d\n", bandas[i].ranking);
    }
}
}

void buscaNomedaBanda(){




}