/**
 * @file 1.c
 * @author Leonardo Novi
 * @brief Escreva um programa que receba um número inteiro representando a quantidade total de segundos e, 
 * usando passagem de parâmetros por referência, converta a quantidade informada de segundos em Horas, Minutos e Segundos. 
 * Imprima o resultado da conversão no formato HH:MM:SS. Utilize o seguinte protótipo da função:
void converteHora(int total_segundos, int* hora, int* min, int* seg)
 * @version 0.1
 * @date 2023-03-29
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void converteHora(int total_segundos, int *hora, int *min, int *seg){

    *hora = total_segundos / 3600;
    *min = (total_segundos % 3600) / 60;
    *seg = (total_segundos % 3600) % 60;
}

int main(){

int total_segundo, hora, min, seg;

printf("Total de segundos: ");
scanf("%d", &total_segundo);
converteHora(total_segundo, &hora, &min, &seg);
printf("Horas: %d:%d:%d \n", hora, min, seg);


    return 0;
}

