#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//função para ler strings e remover o /n



void LerString(char *string, int tamanho)
{
    setbuf(stdin, NULL);
    fgets(string, tamanho, stdin);
    string[strcspn(string, "\n")] = '\0';
}

